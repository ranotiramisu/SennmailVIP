<template>
	<div class="flex items-center h-32px">
		<slot></slot>
	</div>
</template>
