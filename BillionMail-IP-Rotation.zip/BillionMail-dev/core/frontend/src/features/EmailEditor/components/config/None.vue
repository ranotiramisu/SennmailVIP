<template>
	<div class="h-full pb-100px flex items-center justify-center">
		<n-empty size="large" description="Please select a component"></n-empty>
	</div>
</template>
