<template>
	<div class="p-24px">
		<bt-route-tabs></bt-route-tabs>
	</div>
</template>

<script lang="ts" setup></script>
