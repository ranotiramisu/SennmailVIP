/**
 * @description Default layout
 */
export const Layout = () => import('@/layout/index.vue')
