import request from '../index'

export interface IPRotationConfig {
	enabled: boolean
	ips: string[]
	emails_per_ip: number
	current_ip_index: number
	total_emails_sent: number
}

export interface IPRotationStats {
	enabled: boolean
	total_ips: number
	current_ip_index: number
	current_ip: string
	emails_per_ip: number
	emails_sent_current: number
	emails_until_rotate: number
	last_rotation: string
}

export interface SetIPRotationConfigParams {
	enabled: boolean
	ips: string[]
	emails_per_ip: number
}

// Get IP rotation configuration
export const getIPRotationConfig = () => {
	return request.get<{ data: IPRotationConfig }>('/ip_rotation/config')
}

// Set IP rotation configuration
export const setIPRotationConfig = (params: SetIPRotationConfigParams) => {
	return request.post('/ip_rotation/config', params)
}

// Get IP rotation statistics
export const getIPRotationStats = () => {
	return request.get<{ data: IPRotationStats }>('/ip_rotation/stats')
}

// Detect system IPs
export const detectSystemIPs = () => {
	return request.get<{ data: { ips: string[] } }>('/ip_rotation/detect')
}
