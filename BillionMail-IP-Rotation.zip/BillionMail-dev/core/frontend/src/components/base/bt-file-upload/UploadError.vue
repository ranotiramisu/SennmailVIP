<template>
	<div class="drag-icon">
		<i class="i-mdi-alert-circle"></i>
	</div>
	<div class="drag-text text-error">{{ $t('components.upload.error.uploadFailed') }}</div>
</template>
